create view VIEW_ORG as
select GROUPCODE,GROUPNAME,COMPANYCODE,COMPANYNAME,SUBCOMPANYCODE,SUBCOMPANYNAME,TP,case when SHORTNAME is null then SUBCOMPANYNAME else shortname end as shortname,part from (
select a.*,b.TP,b.SHORTNAME,B.PART from (
SELECT '010' as groupcode, '浙江省国际贸易集团有限公司' as groupname,a.DEPARTMENTID as companycode,C.NAME AS COMPANYNAME,
a.POSTID as subcompanycode,b.NAME AS SUBCOMPANYNAME
FROM FINEDB1.FINE_DEP_ROLE a
LEFT JOIN FINEDB1.FINE_POST b on a.postid = b.id
left join FINEDB1.FINE_DEPARTMENT c on a.departmentid = c.id
union
select GROUPCODE,GROUPNAME,COMPANYCODE,COMPANYNAME,SUBCOMPANYCODE,SUBCOMPANYNAME from DIM_ORG
) a
left join DIM_ORG b on a.SUBCOMPANYCODE = b.SUBCOMPANYCODE
)
/


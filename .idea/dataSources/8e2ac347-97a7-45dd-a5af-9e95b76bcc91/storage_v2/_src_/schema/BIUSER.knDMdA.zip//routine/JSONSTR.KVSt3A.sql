create FUNCTION        jsonstr(p_jsonstr varchar2,startkey varchar2,endkey varchar2) RETURN VARCHAR2
IS
  rtnVal VARCHAR2(1000);
  FindIdxS NUMBER(2);
  FindIdxE NUMBER(2);
BEGIN
if endkey='}' then
    rtnVal:=substr(p_jsonstr,(instr(p_jsonstr,startkey)+length(startkey)  +2)
        ,(instr(p_jsonstr,endkey,instr(p_jsonstr,startkey))-instr(p_jsonstr,startkey)-length(startkey)-2));
else
    rtnVal:=substr(p_jsonstr,(instr(p_jsonstr,startkey)+length(startkey)  +2)
        ,(instr(p_jsonstr,endkey,instr(p_jsonstr,startkey))-instr(p_jsonstr,startkey)-length(startkey)-4));
end if;
  RETURN rtnVal;
END jsonstr;
/


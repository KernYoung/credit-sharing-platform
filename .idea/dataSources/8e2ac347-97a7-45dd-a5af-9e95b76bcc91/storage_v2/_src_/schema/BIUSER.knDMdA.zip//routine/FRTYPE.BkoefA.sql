create FUNCTION frtype (TYPEA IN VARCHAR2)
RETURN VARCHAR2
AS 
IS_FIELD VARCHAR2(400);
cursor t_cursor is
    select t.FIELD t_field from DIM_TYC_TYPE t where t.TYPE=TYPEA;
BEGIN
  for temp1 in t_cursor LOOP 
     IS_FIELD := temp1.t_field || ',' || IS_FIELD;
  END LOOP;
	RETURN IS_FIELD;
END frtype;
/


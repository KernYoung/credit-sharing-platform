create type obj_table as object
(
  IS_TYPE varchar2(50),
  IS_FIELD varchar2(50)
)
/


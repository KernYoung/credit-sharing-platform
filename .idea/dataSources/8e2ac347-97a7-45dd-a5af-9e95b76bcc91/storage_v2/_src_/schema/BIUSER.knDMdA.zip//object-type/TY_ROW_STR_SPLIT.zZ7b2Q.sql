create TYPE ty_row_str_split  as object (strValue VARCHAR2 (4000));
/


create trigger "TG_CREDIT_USER_copy_copy_copy1"
    before insert
    on CREDIT_USER_YS
    for each row
    when (new.user_id is null)
begin
select USER_SEQUENCE.nextval into:new.user_id from dual;
end;


/

